import socket
import sys
import p7md5py
import binascii
import struct

HOST, PORT = sys.argv[1], 30007

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Connect to server and send data
    sock.connect((HOST, PORT))
    
    # sign the "ls" command
    sock.send('sign ls')
    signature = sock.recv(1024)[len('signature:'):]

    # forge fake command.
    md5 = p7md5py.md5(('a'*16) + 'ls')
    padding = md5.getpadding()
    cmd = 'ls'+''.join(padding)+';secret'

    # recover the state as it was after the padding was applied.
    signature = binascii.unhexlify(signature)
    md5 = p7md5py.new()
    md5.count[0] = long(64) << 3
    md5.A = long(struct.unpack('<L', signature[:4])[0])
    md5.B = long(struct.unpack('<L', signature[4:8])[0])
    md5.C = long(struct.unpack('<L', signature[8:12])[0])
    md5.D = long(struct.unpack('<L', signature[12:])[0])

    # perform the actual extension on the recovered state
    md5.update(';secret')
    signature = md5.hexdigest()

    # execute the "ls" command, with the signature.
    sock.send('exec %s %s' % (signature, cmd))

    received = sock.recv(1024)
    received = sock.recv(1024)
    print '%s' % (received)
    
finally:
    sock.close()
