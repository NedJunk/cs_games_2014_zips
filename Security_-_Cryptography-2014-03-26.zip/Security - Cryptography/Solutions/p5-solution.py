import socket
import sys
import pickle
import binascii
import time
import logging

from p5paddingoracle import PaddingOracle, BadPaddingException

HOST, PORT = sys.argv[1], 30000

def pkcs5_unpad(s):
    return s[0:-ord(s[-1])]

class PadBuster(PaddingOracle):
    def oracle(self, data):

        time.sleep(0.01)
        
        self.remote_sock.send(binascii.hexlify(data))
        response = self.remote_sock.recv(1024)
        
        if 'hey, are you trying to hack me? this is secure crypto, you fool!' in response:
            raise BadPaddingException
        
        return

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Connect to server and send data
    sock.connect((HOST, PORT))
    
    received = sock.recv(1024)
    time.sleep(0.1)
    
    received = received[len("here's my secret, what's yours? "):]
    received = binascii.unhexlify(received)
    
    #~ print repr(received)
    
    iv = received[:16]
    data = received[16:]
    
    logging.basicConfig(level=logging.CRITICAL)
    
    padbuster = PadBuster()
    padbuster.remote_sock = sock
    decrypted = padbuster.decrypt(data, block_size=16, iv=iv)
    
    print pkcs5_unpad(str(decrypted))
    
finally:
    sock.close()
