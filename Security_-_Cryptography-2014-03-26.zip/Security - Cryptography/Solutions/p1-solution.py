import socket
import sys

import binascii

HOST, PORT = sys.argv[1], 30009

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Connect to server and send data
    sock.connect((HOST, PORT))

    # rc4stream ^ plaintext = ciphertext
    # rc4stream ^ ciphertext = ...

    # the plaintext will look like: \x00[SECRET]
    # we simply send the ciphertext back to the server
    # and the properties of xor will decrypt the SECRET

    sock.send('\x00')
    encrypted = binascii.unhexlify(sock.recv(1024))

    sock.send(encrypted)

    received = binascii.unhexlify(sock.recv(1024))
    print '%s' % (received[1:len(encrypted)])
    
finally:
    sock.close()
