import SocketServer
import os
import binascii
import random
import hmac
import base64

from Crypto.Cipher import AES

SECRET = "Okey, this is one secret protected by REAL strong cryptography."

BLOCK_SIZE = 16

def pkcs5_pad(s):
    return s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * chr(BLOCK_SIZE - len(s) % BLOCK_SIZE)

def pkcs5_unpad(s):
    return s[0:-ord(s[-1])]

def pkcs5_verify(s):
    return s[-ord(s[-1]):] == (s[-1] * ord(s[-1]))

# crypto keys, valid for the duration of the program's life.
aes_key = ''.join(chr(random.randint(0, 0xFF)) for i in range(16))
mac_key = ''.join(chr(random.randint(0, 0xFF)) for i in range(16))

class MyTCPHandler(SocketServer.BaseRequestHandler):

    def protect_data(self, value):
        # This protection makes data impossible to counterfeit!
        
        global aes_key
        global mac_key
        
        iv = ''.join(chr(random.randint(0, 0xFF)) for i in range(16))
        cipher = AES.new(aes_key, AES.MODE_CBC, iv)
        crypted = cipher.encrypt(pkcs5_pad(value))
        
        # sign the blob to prevent padding oracle!
        mac = hmac.new(mac_key, iv+crypted).digest()
        
        return binascii.hexlify(iv+crypted+mac)

    def unprotect_data(self, data):
        global aes_key
        global mac_key
        
        data = binascii.unhexlify(data)
        
        if len(data) < 16*3: # must have at least 1 iv block + 1 data bloc + 1 hmac block.
            raise RuntimeError('no way hackers!')
            return
        
        if len(data) % 16 != 0:
            raise RuntimeError('no way hackers!')
            return
        
        iv = data[:16]
        mac = data[-16:]
        data = data[16:-16]
        
        if mac != hmac.new(mac_key, iv+data).digest():
            raise RuntimeError('no way hackers!')
        
        cipher = AES.new(aes_key, AES.MODE_CBC, iv)
        decrypted = cipher.decrypt(data)
        print repr(decrypted)
        
        if not pkcs5_verify(decrypted):
            raise RuntimeError('no way hackers!')
        
        return pkcs5_unpad(decrypted)
    
    def do_login(self, username, is_admin=0):
        
        iv = ''.join(chr(random.randint(0, 0xFF)) for i in range(16))
        cipher = AES.new(aes_key, AES.MODE_CBC, iv)
        
        username = username.replace('&', '') # illegal character.
        
        cookie = 'username=%s&is_admin=%s' % (self.protect_data(username), self.protect_data(str(is_admin)))
        
        self.request.send("okey %s, you are logged in, send this cookie with every message! cookie=%s" % (username, base64.b64encode(cookie), ))
        
        return

    def validate_cookie(self, cookie):
        
        cookie = base64.b64decode(cookie)
        
        parts = cookie.split('&')
        if parts[0].startswith('username='):
            username = self.unprotect_data(parts[0][len('username='):])
        if parts[1].startswith('is_admin='):
            is_admin = int(self.unprotect_data(parts[1][len('is_admin='):]))
        
        return username, is_admin
    
    def do_authenticated_stuff(self, cmd):
        global SECRET
        
        cookie = cmd[0]
        command = cmd[1]
        
        username, is_admin = self.validate_cookie(cookie)
        
        if command == 'ping':
            self.request.send("pong")
        elif command == 'secret' and is_admin:
            self.request.send("okey %s, here's my secret: %s" % (username, SECRET))
        else:
            self.request.send("what's that?")
        
        return
    
    def handle(self):
        
        self.request.send("please, log in...")
        
        while True:
            s = self.request.recv(4096)
            cmd = s.split(' ')
            
            if cmd[0] == 'login':
                self.do_login(cmd[1])
            else:
                print repr(cmd)
                self.do_authenticated_stuff(cmd)
        
        return

def main():
    HOST, PORT = "0.0.0.0", 30006
    
    SocketServer.TCPServer.allow_reuse_address = True
    server = SocketServer.TCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()
    
    return

if __name__ == '__main__':
    main()
