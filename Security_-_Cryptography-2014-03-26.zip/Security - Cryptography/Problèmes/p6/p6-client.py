import socket
import sys
import binascii
import base64
import time

HOST, PORT = sys.argv[1], 30006

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Connect to server and send data
    sock.connect((HOST, PORT))
    
    received = sock.recv(1024)
    print '> %s' % (received)
    
    data = raw_input("(what's your username?): ")
    sock.send('login %s' % (data, ))
    
    _,_,cookie = sock.recv(1024).partition('cookie=')
    
    while True:
        sock.send('%s ping' % (cookie, ))
        print '< ping'
        
        received = sock.recv(1024)
        print '> %s' % (received)
        
        time.sleep(1)
    
finally:
    sock.close()
