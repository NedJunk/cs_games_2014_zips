import SocketServer

class MyTCPHandler(SocketServer.BaseRequestHandler):

    def handle(self):
        
        while True:
            s = self.request.recv(4096)
            if s == '':
                break

            if s == 'secret.txt':
                break

            self.request.send(file(s, 'rb').read())
        
        return

def main():
    HOST, PORT = "0.0.0.0", 30008
    
    SocketServer.TCPServer.allow_reuse_address = True
    server = SocketServer.TCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()
    
    return

if __name__ == '__main__':
    main()
