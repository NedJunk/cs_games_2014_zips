import socket
import sys

HOST, PORT = sys.argv[1], 30008

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Connect to server and send data
    sock.connect((HOST, PORT))

    sock.send('foo.txt')

    received = sock.recv(1024)
    print 'Response: %s' % (received)
    
finally:
    sock.close()
