//compile: gcc -o p4-server p4-server.c

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>

char *SECRET="Super Duper Secret protected by random cryptography!";

int hex_to_i(char c)
{
    if(c >= '0' && c <= '9')
        return c-'0';
    else
        return c-'a'+10;
    return 0; // meh :3
}

struct {
    char sendBuff[1024];
    char recvBuff[1024];
    char clienthash[32];
    char wantedhash[32];
} data;

void handle_client(int fd)
{
    int i;
    
    // this is a foolproof way of protecting my secret! ~~~PATEND PENDING~~~
    for(i=0;i<32;i++)
        data.wantedhash[i] = rand() % 255;
    
    memset(data.sendBuff, 0, sizeof(data.sendBuff));
    read(fd, data.recvBuff, sizeof(data.recvBuff));
    
    for(i=0;data.recvBuff[i] != 0;i++)
        data.clienthash[i] = (hex_to_i(data.recvBuff[i*2]) << 4) | hex_to_i(data.recvBuff[(i*2)+1]);
    
    printf("client hash: %s\n", data.clienthash);
    printf("wanted hash: %s\n", data.wantedhash);
    
    if(!memcmp(data.clienthash, data.wantedhash, 32)) {
        snprintf(data.sendBuff, sizeof(data.sendBuff), "This is my secret: %s", SECRET);
        write(fd, data.sendBuff, strlen(data.sendBuff));
    }
    else {
        snprintf(data.sendBuff, sizeof(data.sendBuff), "woops, no secret for you :(");
        write(fd, data.sendBuff, strlen(data.sendBuff));
    }
    
    return;
}

int main()
{
    int listenfd = 0, connfd = 0;
    struct sockaddr_in serv_addr; 
    
    srand(time(NULL));
    
    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    memset(&serv_addr, '0', sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(30004); 

    bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)); 

    listen(listenfd, 10); 

    while(1)
    {
        connfd = accept(listenfd, (struct sockaddr*)NULL, NULL); 
        
        handle_client(connfd);
        
        close(connfd);
        sleep(1);
    }

    return 0;
}
