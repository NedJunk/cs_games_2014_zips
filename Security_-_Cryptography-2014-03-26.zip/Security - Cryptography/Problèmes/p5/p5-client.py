import socket
import sys
import pickle
import binascii

HOST, PORT = sys.argv[1], 30000

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Connect to server and send data
    sock.connect((HOST, PORT))
    
    received = sock.recv(1024)
    print '> %s' % (received)
    
    # unfortunately we don't have the server key, so it will probably not like our secret :(
    data = raw_input("(what's your secret?): ")
    #~ sock.send(binascii.hexlify(data))
    sock.send(data)
    
    received = sock.recv(1024)
    print 'Response: %s' % (received)
    
finally:
    sock.close()
