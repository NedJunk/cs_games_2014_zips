import SocketServer
import os
import binascii
import random

from Crypto.Cipher import AES

SECRET = "this secret, you cannot get. respect the cryptography."

BLOCK_SIZE = 16

def pkcs5_pad(s):
    return s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * chr(BLOCK_SIZE - len(s) % BLOCK_SIZE)

def pkcs5_unpad(s):
    return s[0:-ord(s[-1])]

def pkcs5_verify(s):
    print repr(s[-ord(s[-1]):])
    print repr(s[-1] * ord(s[-1]))
    return s[-ord(s[-1]):] == (s[-1] * ord(s[-1]))

# crypto key, valid for the duration of the program's life.
aes_key = ''.join(chr(random.randint(0, 0xFF)) for i in range(16))

class MyTCPHandler(SocketServer.BaseRequestHandler):

    def handle(self):
        global aes_key
        
        iv = ''.join(chr(random.randint(0, 0xFF)) for i in range(16))
        cipher = AES.new(aes_key, AES.MODE_CBC, iv)
        crypted = cipher.encrypt(pkcs5_pad(SECRET))
        
        self.request.send("here's my secret, what's yours? %s" % (binascii.hexlify(iv+crypted), ))
        
        while True:
            s = self.request.recv(4096)
            s = binascii.unhexlify(s)
            
            if len(s) < 32:
                self.request.send("ciphertext should have an iv! (16 first bytes)")
                return
            
            if len(s) % 16 != 0:
                self.request.send("ciphertext must be modulo 16!")
                return
            
            iv = s[:16]
            data = s[16:]
            
            cipher = AES.new(aes_key, AES.MODE_CBC, iv)
            decrypted = cipher.decrypt(data)
            print repr(decrypted)
            
            # Check for invalid padding!!! This is how hackers get ya!
            if not pkcs5_verify(decrypted):
                self.request.send("hey, are you trying to hack me? this is secure crypto, you fool!")
            else:
                client_secret = pkcs5_unpad(decrypted)
                self.request.send("well received.")
                print repr(client_secret)
        
        return

def main():
    HOST, PORT = "0.0.0.0", 30000
    
    SocketServer.TCPServer.allow_reuse_address = True
    server = SocketServer.TCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()
    
    return

if __name__ == '__main__':
    main()
