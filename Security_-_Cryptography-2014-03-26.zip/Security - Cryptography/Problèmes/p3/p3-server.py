import SocketServer
import pickle
import os

class MyTCPHandler(SocketServer.BaseRequestHandler):

    def handle(self):
        
        s = self.request.recv(4096)
        obj = pickle.loads(s)
        
        self.request.send('I correctly received: %s' % (obj, ))
        
        return

def main():
    HOST, PORT = "0.0.0.0", 30003
    
    SocketServer.TCPServer.allow_reuse_address = True
    server = SocketServer.TCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()
    
    return

if __name__ == '__main__':
    main()
