import socket
import sys
import pickle
import subprocess

HOST, PORT = sys.argv[1], 30003

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Connect to server and send data
    sock.connect((HOST, PORT))
    
    obj = pickle.dumps("this is my message")
    sock.send(obj)
    
    received = sock.recv(1024)
    print 'Response: %s' % (received)
    
finally:
    sock.close()
