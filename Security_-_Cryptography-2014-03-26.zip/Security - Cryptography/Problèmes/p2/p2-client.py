import socket
import sys
import time

HOST, PORT = sys.argv[1], 30002

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Connect to server and send data
    sock.connect((HOST, PORT))
    
    data = raw_input('Username: ')
    sock.sendall(data)
    time.sleep(0.1) # sleep to make sure lines are sent in separate packets
    
    data = raw_input('Password: ')
    sock.sendall(data)
    # Receive data from the server and shut down
    received = sock.recv(1024)
    
    print 'Response: %s' % (received)
    
finally:
    sock.close()
