import sqlite3
import SocketServer
import os

db = None

class MyTCPHandler(SocketServer.BaseRequestHandler):

    def handle(self):
        global db
        
        c = db.cursor()
        
        # get username and password, up to 1024 chars!
        user = self.request.recv(1024)
        passwd = self.request.recv(1024)
        
        ## (steve): I fixed the bug by escaping the offending character... hope this is enough!
        user = user.replace("'", "\\'")
        passwd = passwd.replace("'", "\\'")
        print repr(user), repr(passwd)
        try:
            q = "select realname from users where username = '%s' and password = '%s';" % (user, passwd)
            print q
            realname = c.execute(q).fetchone()
            if realname: # the query worked, so the user exists!
               self.request.send("Welcome, %s" % realname)
            else:
               self.request.send("DENIED!!!!")
        except:
            self.request.send('An error occured :(')
            raise
        
        return

def server():
    HOST, PORT = "0.0.0.0", 30002
    
    SocketServer.TCPServer.allow_reuse_address = True
    server = SocketServer.TCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()
    
    return

def init():
    global db
    
    db = sqlite3.connect('p2.db')
    
    c = db.cursor()
    
    c.execute("create table if not exists users (username unique, password, realname)")
    
    c.execute("insert or replace into users values ('admin', 'this is a secret you must retrieve', 'The All Powerful Administrator')")
    c.execute("insert or replace into users values ('tyler', 'dumb~passwurd', 'Tyler Durden')")
    c.execute("insert or replace into users values ('bob', 'beep boopidy bop', 'Robert Paulson')")
    
    db.commit()
    
    return

def main():
    init()
    server()
    return

if __name__ == '__main__':
    main()
