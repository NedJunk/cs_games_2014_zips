import SocketServer
import random
import base64
import binascii

# just an encryption key.
crypt_key = ''.join(chr(random.randint(0, 0xFF)) for i in range(16))

# get this secret.
SECRET = 'this is the secret'

#RC4 Implementation
def rc4crypt(data, key):
    x = 0
    box = range(256)
    for i in range(256):
        x = (x + box[i] + ord(key[i % len(key)])) % 256
        box[i], box[x] = box[x], box[i]
    x = 0
    y = 0
    out = []
    for char in data:
        x = (x + 1) % 256
        y = (y + box[x]) % 256
        box[x], box[y] = box[y], box[x]
        out.append(chr(ord(char) ^ box[(box[x] + box[y]) % 256]))
    
    return ''.join(out)

class MyTCPHandler(SocketServer.BaseRequestHandler):

    def handle(self):
        
        while True:
            s = self.request.recv(4096)
            if s == '':
                break

            # they can't decrypt the secret, so who cares if we send it to them. right?
            self.request.send(binascii.hexlify(rc4crypt(s+SECRET, crypt_key)))
        
        return

def main():
    HOST, PORT = "0.0.0.0", 30009
    
    SocketServer.TCPServer.allow_reuse_address = True
    server = SocketServer.TCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()
    
    return

if __name__ == '__main__':
    main()
