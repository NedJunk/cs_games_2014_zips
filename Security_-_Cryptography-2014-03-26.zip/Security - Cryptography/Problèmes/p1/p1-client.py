import socket
import sys

HOST, PORT = sys.argv[1], 30009

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Connect to server and send data
    sock.connect((HOST, PORT))

    sock.send('data to encrypt')

    received = sock.recv(1024)
    print 'Encrypted blob: %s' % (received)
    
finally:
    sock.close()
