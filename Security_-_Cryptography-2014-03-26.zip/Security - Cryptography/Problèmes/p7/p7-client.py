import socket
import sys

HOST, PORT = sys.argv[1], 30007

try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Connect to server and send data
    sock.connect((HOST, PORT))
    
    # sign the "ls" command
    sock.send('sign ls')
    signature = sock.recv(1024)[len('signature:'):]
    print repr(signature)
    
    # execute the "ls" command, with the signature.
    sock.send('exec %s ls' % (signature, ))

    received = sock.recv(1024)
    print 'Response: %s' % (received)
    
finally:
    sock.close()
