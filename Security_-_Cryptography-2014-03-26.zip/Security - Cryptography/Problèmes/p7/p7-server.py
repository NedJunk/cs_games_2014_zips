import SocketServer
import random
import md5py

# just a signature key.
sign_key = ''.join(chr(random.randint(0, 0xFF)) for i in range(16))

# get this secret.
SECRET = 'this is the secret'

class MyTCPHandler(SocketServer.BaseRequestHandler):

    def handle(self):
        
        while True:
            s = self.request.recv(4096)
            if s == '':
                break
            cmd, arg = s.split(' ', 1)

            if cmd == 'sign':
                if 'secret' in arg:
                    self.request.send('No no, I cannot sign that command!')
                else:
                    # Prepend the signature key to the message to sign. 
                    # They don't have the signature, so they can't
                    # forge any message.
                    sign_message = sign_key + arg
                    signature = md5py.new(sign_message).hexdigest()
                    self.request.send('signature:' + signature)
            elif cmd == 'exec':
                their_signature, arg = arg.split(' ', 1)

                print repr(cmd), repr(arg)
                sign_message = sign_key + arg
                signature = md5py.new(sign_message).hexdigest()

                if signature != their_signature:
                    self.request.send('That signature is invalid, use the "sign" command.')
                else:
                    for cmd in arg.split(';'):
                        self.eval_command(cmd)
        
        return

    def eval_command(self, cmd):
        if cmd == 'ls':
            self.request.send(repr(['.', '..', 'foo', 'bar']))
        elif cmd == 'say':
            self.request.send('waaaaaat?')
        elif cmd == '2+2':
            self.request.send('4')
        elif cmd == 'secret':
            self.request.send(SECRET)
        else:
            self.request.send('sorry, I do not know that command.')
        return

def main():
    HOST, PORT = "0.0.0.0", 30007
    
    SocketServer.TCPServer.allow_reuse_address = True
    server = SocketServer.TCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()
    
    return

if __name__ == '__main__':
    main()
